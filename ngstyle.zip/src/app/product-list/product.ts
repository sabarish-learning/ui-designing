 export class Product{
 prodId: number;
  prodName:string ;
  desc:string;
  qty:number;
  price:number;
 }