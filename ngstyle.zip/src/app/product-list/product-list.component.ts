import { Component } from '@angular/core';

import { products } from '../products';
import {Product} from './product';
@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
 

prod:Product[]=[
		{prodId:1001,prodName:'tv',desc:'sample',qty:8,price:9898},
		{prodId:1002,prodName:'ac',desc:'data',qty:8,price:8900},
		{prodId:1001,prodName:'mobile',desc:'sample',qty:8,price:30898}
];
people: any[] = [
    {
      'state': 'Chennai',
      'people': [
        {
          "name": "david"
        },
        {
          "name": "Mike"
        },
      ]
    },
    {
      'state': 'Mumbai',
      'people': [
        {
          "name": "Pankaj"
        },
        {
          "name": "Akash"
        },
        {
          "name": "Ankit"
        }
      ]
    }
  ]; 
}

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/