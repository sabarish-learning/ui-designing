import React from 'react';

import EmployeeList from './EmployeeList';
import Forms from './Forms';
const aName='value from app';

class App extends React.Component  {
  constructor(props) {
    super(props);
this.state = {
      empName: '',
      desig: '',
      age:'',
      employees:[
        {
              empName:'charlie',
              desig:'admin',
              age:34
        },
        {
          empName:'Anup',
          desig:'Manager',
          age:32
        },
        {
          empName:'Alex',
          desig:'developer',
          age:26
        }
      ]
    }
this.changeInput=this.changeInput.bind(this);
this.AddRow=this.AddRow.bind(this);
  };

  changeInput(event){
   
    this.setState({[event.target.name]:event.target.value}) // getting value using input name attribute
  }

  AddRow(event){
  event.preventDefault();
  const emp = this.state.employees;

  emp.push({
    empName: this.state.name,
    desig: this.state.design1,
    age:this.state.age1,
  });
  console.log(emp);

  this.setState({
    emp,
    empName: '',
    desig: '',
    age: ''
  });
};
  
  deleteEmployee=(index)=>{
    const empStat=this.state.employees;

    this.setState(
      {
        employees: empStat.filter(
          (em,ind)=>{
            return ind!==index
          }),
      })
  }
  render(){
    
    return (
      <div>
        <FormComp/>
    <EmployeeList employees={this.state.employees} rem={this.deleteEmployee}/>
    <Forms AddRow={ this.AddRow} changeInput={ this.changeInput } />
    </div>
    );
  }
}

class FormComp extends React.Component {
  constructor(props) {
    super(props);
    this.state = { username: '' };
    this.changeName=this.changeName.bind(this);
  }
  changeName(event){
    console.log('hi');
    this.setState({username:event.target.value})
  }
  render(){
  return(
    <form>
      <h1>{this.state.username}</h1>
      <input type='text'  onChange={this.changeName}/>
    </form>
  )
  }
}
export default App;
