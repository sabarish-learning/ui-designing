import React from 'react';


class Forms  extends React.Component {

render(){
      return(
          <div>
        <form onSubmit={this.props.AddRow}>
         Name: <input type='text' name="name"  onChange={this.props.changeInput}/><br/>
      Designation:<input type='text' name="design1" onChange={this.props.changeInput}/><br/>
         Age:<input type='text' name="age1" onChange={this.props.changeInput}/><br/>
         <input type="submit" value="Add" />
        </form>
        </div>
      )
      }
}

export default Forms;