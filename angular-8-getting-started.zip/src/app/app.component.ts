import { Component } from '@angular/core';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  pname:string ='';
   pcity:string='';
  pstate:string='';
  bname:string='';
  bcity:string='';
  bstate:string='';
filladdress($event){
  if($event.target.checked== true){
 this.bname=this.pname;
 this.bcity=this.pcity;
 this.bstate=this.pstate;
  
  }else
  {
    this.bname="";
    this.bcity="";
    this.bstate="";
  }
  
}
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/